<?php

define('DB_HOST', 'dbsrv2.cs.fsu.edu');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_NAME', '');